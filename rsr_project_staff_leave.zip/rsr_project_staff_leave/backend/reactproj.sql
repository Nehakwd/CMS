-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 25, 2022 at 06:55 PM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 8.1.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `reactproj`
--

-- --------------------------------------------------------

--
-- Table structure for table `appliedleave`
--

CREATE TABLE `appliedleave` (
  `id` int(225) NOT NULL,
  `email` varchar(50) NOT NULL,
  `name_of_applicant` varchar(225) NOT NULL,
  `College` varchar(225) NOT NULL,
  `Designation` varchar(225) NOT NULL,
  `Leave_Aplied_from` date NOT NULL,
  `applied_leave_till` date NOT NULL,
  `No_of_days` int(100) NOT NULL,
  `Nature_of_Leave` varchar(50) NOT NULL,
  `Reason_for_leave` varchar(225) NOT NULL,
  `address_of_applicant` varchar(255) NOT NULL,
  `Mobile_no` int(20) NOT NULL,
  `Details_of_Adjustment` varchar(225) NOT NULL,
  `status_h_denied` varchar(10) DEFAULT NULL,
  `status_h_forwarded` varchar(10) DEFAULT NULL,
  `status_p_denied` varchar(10) NOT NULL,
  `status_p_accepted` varchar(10) NOT NULL,
  `Applied_leave` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `appliedleave`
--

INSERT INTO `appliedleave` (`id`, `email`, `name_of_applicant`, `College`, `Designation`, `Leave_Aplied_from`, `applied_leave_till`, `No_of_days`, `Nature_of_Leave`, `Reason_for_leave`, `address_of_applicant`, `Mobile_no`, `Details_of_Adjustment`, `status_h_denied`, `status_h_forwarded`, `status_p_denied`, `status_p_accepted`, `Applied_leave`) VALUES
(1, 'shivam@rungtacolleges.com', 'Shivam Sharma', 'RSRRCET', 'HOD', '0000-00-00', '0000-00-00', 1, 'CL', 'OUT OF STATION', 'KOHKA', 808584020, 'ABC', '0', '0', '0', '0', '2022-07-25 14:57:02'),
(2, 'deepshikha@rungtacolleges.com', 'Deepshikha Singh', 'RSRRCET', 'FACULTY', '0000-00-00', '0000-00-00', 1, 'ML', 'OUT OF STATION', 'BHILAI', 834944210, 'ABC', '0', '1', '0', '0', '2022-07-25 15:08:54'),
(3, 'neha@rungtacolleges.com', 'Neha Sahu', 'RSRRCET', 'FACULTY', '0000-00-00', '0000-00-00', 1, 'OL', 'ABC', 'KAWARDHA', 808584020, 'ABC', '0', '0', '0', '0', '0000-00-00 00:00:00'),
(4, 'megha@rungtacolleges.com', 'Megha Khalkho', 'RSRRCET', 'FACULTY', '0000-00-00', '0000-00-00', 1, 'SL', 'ABC', 'BHILAI', 808584020, 'ABC', '0', '0', '0', '0', '0000-00-00 00:00:00'),
(5, 'mantasha@rungtacolleges.com', 'Mantasha Sarfaraj', 'RSRRCET', 'FACULTY', '0000-00-00', '0000-00-00', 1, 'C-OFF', 'ABC', 'BHILAI', 626530129, 'ABC', '0', '0', '0', '0', '0000-00-00 00:00:00'),
(6, 'sachin@rungtacolleges.com', 'Sachin Harne', 'RSRRCET', 'PRINCIPAL', '0000-00-00', '0000-00-00', 1, 'CL', 'ABC', 'BHILAI', 626530129, 'ABC', '0', '1', '0', '0', '2022-07-25 16:49:50'),
(7, 'shivamsharma@rungtacolleges.com', 'Shivam Sharma', 'RSR - RCET', 'Director', '0000-00-00', '0000-00-00', 22, 'OL type', 'feaver cold cough', 'arya nagar kohka', 2147483647, 'altered by sachin sir', NULL, NULL, '', '', '2022-07-25 07:43:48'),
(8, 'shivamsharma@rungtacolleges.com', 'Shivam Sharma', 'RSR - RCET', 'Director', '0000-00-00', '0000-00-00', 22, 'OL type', 'feaver cold cough', 'arya nagar kohka', 2147483647, 'altered by sachin sir', NULL, NULL, '', '', '2022-07-25 07:43:55');

-- --------------------------------------------------------

--
-- Table structure for table `dummy`
--

CREATE TABLE `dummy` (
  `Id` int(188) NOT NULL,
  `email` varchar(200) NOT NULL,
  `name` char(200) NOT NULL,
  `college` varchar(500) NOT NULL,
  `designation` varchar(100) NOT NULL,
  `Address_of_applicant` varchar(225) NOT NULL,
  `phoneno` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `dummy`
--

INSERT INTO `dummy` (`Id`, `email`, `name`, `college`, `designation`, `Address_of_applicant`, `phoneno`) VALUES
(1, 'shivam@rungtacolleges.com', 'Shivam Sharma', 'RSRRCET', 'HOD', 'kohka', '8085840201'),
(2, 'deepshikha@rungtacolleges.com', 'Deepshikha Singh', 'RSRRCET', 'FACULTY', 'bhilai', '834944210'),
(3, 'neha@rungtacolleges.com', 'Neha Sahu', 'RSRRCET', 'FACULTY', 'kawardha', '808584020'),
(4, 'megha@rungtacolleges.com', 'Megha Kalkho', 'RSRRCET', 'FACULTY', 'jaspur', '808584020'),
(5, 'mantasha@rungtacolleges.com', 'Mantasha Sarfaraj', 'RSRRCET', 'FACULTY', 'bhilai', '626530129'),
(6, 'sachin@rungtacolleges.com', 'Sachin Harne', 'RSRRCET', 'PRINCIPAL', 'bhilai', '626530129');

-- --------------------------------------------------------

--
-- Table structure for table `logintable`
--

CREATE TABLE `logintable` (
  `id` int(11) NOT NULL,
  `emailid` varchar(40) DEFAULT NULL,
  `password` varchar(30) DEFAULT NULL,
  `newpass` varchar(30) DEFAULT NULL,
  `user_type` varchar(15) NOT NULL,
  `logintime` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `logintable`
--

INSERT INTO `logintable` (`id`, `emailid`, `password`, `newpass`, `user_type`, `logintime`) VALUES
(1, 'shivam@rungtacolleges.com', '123', NULL, 'admin', '0000-00-00 00:00:00'),
(2, 'deepshikha@rungtacolleges.com', '123', NULL, 'teacher', '0000-00-00 00:00:00'),
(3, 'neha@rungtacolleges.com', '123', NULL, 'hod', '0000-00-00 00:00:00'),
(4, 'megha@rungtacolleges.com', '123', NULL, 'teacher', '0000-00-00 00:00:00'),
(5, 'mantasha@rungtacolleges.com', '123', NULL, 'hod', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `viewleave`
--

CREATE TABLE `viewleave` (
  `id` int(40) NOT NULL,
  `emailid` varchar(255) NOT NULL,
  `Cl` double NOT NULL,
  `taken_CL` float NOT NULL,
  `Bonus_CL` float NOT NULL,
  `Ml` double NOT NULL,
  `taken_ML` float NOT NULL,
  `Bonus_ML` float NOT NULL,
  `Ol` double NOT NULL,
  `taken_OL` float NOT NULL,
  `Bonus_OL` float NOT NULL,
  `Sl` double NOT NULL,
  `taken_SL` float NOT NULL,
  `Bonus_Sl` float NOT NULL,
  `Coff` double NOT NULL,
  `taken_C-off` float NOT NULL,
  `Bonus_C-off` float NOT NULL,
  `update_on` varchar(40) NOT NULL,
  `update_by` varchar(40) NOT NULL,
  `C` varchar(40) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `viewleave`
--

INSERT INTO `viewleave` (`id`, `emailid`, `Cl`, `taken_CL`, `Bonus_CL`, `Ml`, `taken_ML`, `Bonus_ML`, `Ol`, `taken_OL`, `Bonus_OL`, `Sl`, `taken_SL`, `Bonus_Sl`, `Coff`, `taken_C-off`, `Bonus_C-off`, `update_on`, `update_by`, `C`) VALUES
(1, 'shivam@rungtacolleges.com', 5, 0, 0, 6, 0, 0, 5.5, 0, 0, 6, 0, 0, 8, 0, 0, '', '', ''),
(2, 'deepshikha@rungtacolleges.com', 5, 0, 0, 6, 0, 0, 5.5, 0, 0, 6, 0, 0, 8, 0, 0, '', '', ''),
(3, 'neha@rungtacolleges.com', 5, 0, 0, 6, 0, 0, 5.5, 0, 0, 6, 0, 0, 8, 0, 0, '', '', ''),
(4, 'megha@rungtacolleges.com', 5, 0, 0, 6, 0, 0, 5.5, 0, 0, 6, 0, 0, 8, 0, 0, '', '', ''),
(5, 'mantasha@rungtacolleges.com', 5, 0, 0, 6, 0, 0, 5.5, 0, 0, 6, 0, 0, 8, 0, 0, '', '', '');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `appliedleave`
--
ALTER TABLE `appliedleave`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `dummy`
--
ALTER TABLE `dummy`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `logintable`
--
ALTER TABLE `logintable`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `viewleave`
--
ALTER TABLE `viewleave`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `appliedleave`
--
ALTER TABLE `appliedleave`
  MODIFY `id` int(225) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `dummy`
--
ALTER TABLE `dummy`
  MODIFY `Id` int(188) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `logintable`
--
ALTER TABLE `logintable`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `viewleave`
--
ALTER TABLE `viewleave`
  MODIFY `id` int(40) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
