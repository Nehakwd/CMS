import { createStackNavigator } from "react-navigation-stack";
import { createAppContainer } from "react-navigation";
import SignIn from "../components/SignIn";
import SignUp from "../components/SignUp";
import Home from "../components/Home";
import PrincipalPage from "../components/PrincipalPage";
import Adminhome from "../components/Adminhome";
import Viewleave from "../components/Viewleave";
import Viewreport from "../components/Viewreport";
import Applyleave from "../components/Applyleave";
import LeaverequestHOD from "../components/LeaverequestHOD";
import LeaverequestPrincipal from "../components/LeaverequestPrincipal";



const screens = {
    SignInScreen: {
        screen: SignIn,
    },
    SignUpScreen: {
        screen: SignUp,
    },
    HomeScreen: {
        screen: Home,
    },
    AdminhomeScreen: {
        screen: Adminhome,
    },
    PrincipalPageScreen: {
        screen: PrincipalPage,
    },
    ViewleaveScreen: {
      screen: Viewleave,
    },
    ApplyleaveScreen: {
      screen: Applyleave,
    },
    ViewreportScreen: {
      screen: Viewreport,
    },
    LeaverequestHODScreen: {
      screen: LeaverequestHOD,
    },
    LeaverequestPrincipalScreen: {
      screen: LeaverequestPrincipal,
    }


}
const homeStack = createStackNavigator(
    screens,
    {
        defaultNavigationOptions: {
            headerStyle: {
                backgroundColor: "pink",
            },
            headerTintColor: '#fff',
            headerTitleStyle: {
                textAlign:'center',
                fontWeight: 'bold',
            },
        },
    },
    {initialRouteName: 'SignUpScreen'}
    );

export default createAppContainer(homeStack);