import React, {useState,useEffect} from 'react';
import { Text, View, StyleSheet } from 'react-native';



export default function App() {
  const[cl, setCl]=useState([]);
   const[ml, setMl]=useState([]);
    const[ol, setOl]=useState([]);
     const[sl, setSl]=useState([]);
      const[coff, setCoff]=useState([]);

    // const url= "http://localhost/s_leavereport/api.php";
    // const url= "http://localhost/phpapidab/fetching_leave.php";
   



    useEffect(()=>{
      var APIURL = "http://localhost/phpapidab/fetching_leave.php";

      var headers = {
        'Accept' : 'application/json',
        'Content-Type' : 'application/json'
      };
            
      var Data ={
        Email: "shivam@rungtacolleges.com"
      };

      fetch(APIURL,{
        method: 'POST',
        headers: headers,
        body: JSON.stringify(Data)
      })
      .then((Response)=>Response.json())
      .then((Response)=>{
        // alert(Response[0].Cl)
          // console.log(Response[0].Cl)
          setCl(Response[0].Cl);
          setMl(Response[0].Ml);
          setOl(Response[0].Ol);
          setSl(Response[0].Sl);
          setCoff(Response[0].Coff);
        // console.log(Data);
      })
      .catch((error)=>{
        console.error("ERROR FOUND" + error);
      })      
    },  []);
  return (
    <View style={styles.container}>

     <Text style={styles.paragraph}>
        <h4>Cl    :   {cl}</h4>
        <h4>Ml    :   {ml}</h4>
        <h4>Ol    :   {ol}</h4>
        <h4>Sl    :   {sl}</h4>
        <h4>C-off :   {coff}</h4>
  
      </Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    //paddingTop: Constants.statusBarHeight,
    backgroundColor: '#ecf0f1',
    padding: 8,
  },
  paragraph:{
    margin: 24,
    fontsize: 14,
    fontWeight: 'bold',
    textAlign: 'center',
    backgroundColor: 'pink',
  },
  
});