import { StyleSheet } from 'react-native'

const styles = StyleSheet.create({
    view:{
        width: '100%',
        height: '100%',
        justifyContent: 'center',
        alignItems: 'center',
        backgroundColor: "cream", 
        padding:100,

    },
    txt:{
        // backgroundColor: "black", 
        color: "#fff", 
        fontSize: 80
    },
    appButtonContainer: {
    elevation: 8,
    backgroundColor: "pink",
    borderRadius: 10,
    paddingVertical: 30,
    paddingHorizontal: 12,
  },
  appButtonText: {
    fontSize: 18,
    color: "#fff",
    fontWeight: "bold",
    alignSelf: "center",
    textTransform: "uppercase"
  }
    
    
    
    
})

export default styles;