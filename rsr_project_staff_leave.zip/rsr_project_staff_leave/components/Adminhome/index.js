import React, { Component } from 'react';
import { View, Text, TouchableOpacity} from 'react-native';
import styles from './style';


export default class Adminhome extends Component {
  constructor(props) {
    super(props);
    this.state = {
    };
  }

  render() {
    return (
      <View  style={styles.view}>
       <Text>welcome</Text>
       <TouchableOpacity onPress={() => this.props.navigation.navigate('ViewleaveScreen')} style={styles.appButtonContainer}>
       <Text style={styles.appButtonText}>view leave</Text>
       </TouchableOpacity>
       <TouchableOpacity onPress={() => this.props.navigation.navigate('ApplyleaveScreen')} style={styles.appButtonContainer}>
       <Text style={styles.appButtonText}>Apply leave</Text>
       </TouchableOpacity>
       <TouchableOpacity onPress={() => this.props.navigation.navigate('ViewreportScreen')} style={styles.appButtonContainer}>
       <Text style={styles.appButtonText}>view report</Text>
       </TouchableOpacity>
       <TouchableOpacity onPress={() => this.props.navigation.navigate('LeaverequestHODScreen')} style={styles.appButtonContainer}>
       <Text style={styles.appButtonText}>leave request</Text>
       </TouchableOpacity>

      </View>
    );
  }
}