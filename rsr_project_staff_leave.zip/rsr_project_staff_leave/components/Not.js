import React, { Component } from 'react';
import 'rsuite/dist/styles/rsuite-default.css';
import { Message } from 'rsuite'
 
export default class Notify extends Component {
  constructor(props) {
    super(props);
    this.state = {
    };
  }


render() {
return (
    <div style={{
    display: 'block', width: 700, paddingLeft: 30
    }}>
    <h4>React Suite Message Component</h4>
    <Message type="success"
            description="This is Success Message" />
    <Message type="error"
            description="This is Error Message" />
    <Message type="info"
            description="This is Informational Message" />
    <Message type="warning"
            description="This is Warning Message" />
    </div>
);
}
}