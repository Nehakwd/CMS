import { StatusBar } from 'expo-status-bar';
import React, { useState, useEffect } from 'react';
import { StyleSheet, Text, View} from 'react-native';
import axios from 'axios';
import DataTable from "react-data-table-component";
//import {Button as styledButton} from 'component-library'
export default function App() {
  let [data, setData] = useState([]);
  //Data Fetching
  useEffect(() => {
    const fetchData = async () => {
      const result = await axios(
        'http://localhost/phpapidab/details_from_applied_leave_to_principal.php',
      );
 
      setData(result.data);
    };
 
    fetchData();
  }, []);
///////////////////////////////useEffect code id ended//////////////////////////////


  function set_principal_d(x){
    console.log(x);
    var APIURL = "http://localhost/phpapidab/updation_of_appliedleave_by_principal.php";

      var headers = {
        'Accept' : 'application/json',
        'Content-Type' : 'application/json'
      };
            
      var Data ={
        Id: x,
        Principal_Deny:"1",
        Principal_Accepted:"0"
      };
      

      fetch(APIURL,{
        method: 'POST',
        headers: headers,
        body: JSON.stringify(Data)
      })
      .then((Response)=>Response.json())
      .then((Response)=>{
        alert(Response[0].Message)
        
        console.log(Data);
      })
      .catch((error)=>{
        console.error("ERROR FOUND" + error);
      })
  }


  function set_principal_a(x){
    // setHod_f(1);
    console.log(x);
    var APIURL = "http://localhost/phpapidab/updation_of_appliedleave_by_principal.php";

      var headers = {
        'Accept' : 'application/json',
        'Content-Type' : 'application/json'
      };
            
      var Data ={
        Id: x,
        Principal_Deny:"0",
        Principal_Accepted:"1"
      };
      

      fetch(APIURL,{
        method: 'POST',
        headers: headers,
        body: JSON.stringify(Data)
      })
      .then((Response)=>Response.json())
      .then((Response)=>{
        alert(Response[0].Message)
        
        console.log(Data);
      })
      .catch((error)=>{
        console.error("ERROR FOUND" + error);
      })
  }
  //Table Headings
  const columns = [
    
    {
      name: "Id",
      selector: "id",
      sortable: true
    },
    {
      name: "Email",
      selector: "email",
      sortable: true
    },
    {
      name: "Name",
      selector: "Name",
      sortable: true
      
    },
    {
      name: "College",
      selector: "College",
      sortable: true,
      
    },
    {
      name: "Designation",
      selector: "Designation",
      sortable: true
      
    },
    {
      name: "Leave Applied from",
      selector: "Leave_Aplied_from",
      sortable: true
      
    },
    {
      name: "Leave applied to",
      selector: "to",
      sortable: true
      
    },
    {
      name: "No of days",
      selector: "No_of_days",
      sortable: true,
      
    },
    {
      name: "Nature of leave",
      selector: "Nature_of_Leave",
      sortable: true,
      
    },
    {
      name: "Reason for leave",
      selector: "Reason_for_leave",
      sortable: true
      
    },
    {
      name: "Address",
      selector: "address",
      sortable: true
      
    },
    {
      name: "Contact Number",
      selector: "Mobile_no",
      sortable: true
      
    },
    {
      name: "Details of adjustment",
      selector: "Details_of_Adjustment",
      sortable: true,
      
    },
    {
    name: "Date of applied",
      selector: "Applied_leave",
      sortable: true,
      
    },
    {
    // id:"2",
    // x:"json_decode(id)",
    
    // data:"data.id",
    cell:(row) => <button onClick={(id)=>{set_principal_d(row.id)}} >Reject {row.id}</button>,
    ignoreRowClick: true,
    allowOverflow: true,
    button: true,
  },
    {
    cell:(row) => <button onClick={(id)=>{set_principal_a(row.id)}}  >Approve {row.id}</button>,
    ignoreRowClick: true,
    allowOverflow: true,
    button: true,
  }
    
    
  ];
  return (
    <view>
    
          <DataTable
          
            title="Leave Requests"
            columns={columns}
            data={data}
            
          
            pagination
            
             
            
          />
      
      </view>
  );
}