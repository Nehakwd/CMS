import React, { useState,useEffect,Component } from 'react';
import { View, Text, TouchableOpacity} from 'react-native';
import styles from './style';


export default class Applyleave extends Component {
  constructor(props) {
    super(props);
    this.state = {
    };
    
  }
  

  render() {
    return (
      <View style={styles.container}>
    
      <Text>
        Hello
      </Text>
    </View>
    );
  }
}